﻿using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Windowing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.UI;
using Microsoft.UI.Composition.SystemBackdrops;
using Microsoft.UI.Composition;
using WinRT;
using znMusicPlayerWUI.Helpers;
using znMusicPlayerWUI.Pages;
using znMusicPlayerWUI.Pages.MusicPages;
using Microsoft.UI.Xaml.Input;
using Windows.Graphics;
using System.Runtime.InteropServices;
using WinRT.Interop;
using NAudio.Wave;
using Microsoft.UI.Xaml.Hosting;
using System.Collections.ObjectModel;
using znMusicPlayerWUI.Controls;
using NAudio.Gui;
using System.Runtime.Intrinsics.Arm;
using Windows.Services.Store;
using znMusicPlayerWUI.Windowed;
using System.Diagnostics;
using System.Reflection.Metadata;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace znMusicPlayerWUI
{
    /// <summary>
    /// An empty window that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainWindow : Window
    {
        public static UIElement SContent;
        public static Window SWindow;
        public static MusicPage SMusicPage = new();
        public static Grid STopControlsBaseGrid;
        public static Grid SWindowGridBaseTop;
        public static Grid SWindowGridBase;
        public static Grid SVolumeBaseGrid;
        public static Grid SMusicPageBaseGrid;
        public static ListView SPlayingListBaseView;
        public static Grid SPlayingListBaseGrid;
        public static Frame SMusicPageBaseFrame;
        public static Frame SPlayContent;
        public static TeachingTip teachingTipVolume;
        public static TeachingTip teachingTipPlayingList;
        static ContentDialog AsyncDialog = null;

        public delegate void WindowViewStateChangedDelegate(bool isView);
        public static event WindowViewStateChangedDelegate WindowViewStateChanged;

        public MainWindow()
        {
            SWindow = this;
            this.InitializeComponent();
            WindowGridBase.DataContext = this;
            SContent = this.Content;
            SNavView = NavView;
            SContentFrame = ContentFrame;
            STopControlsBaseGrid = TopControlsBaseGrid;
            SWindowGridBaseTop = WindowGridBase;
            SWindowGridBase = GridBase;
            SVolumeBaseGrid = VolumeBaseGrid;
            SMusicPageBaseGrid = MusicPageBaseGrid;
            SPlayingListBaseGrid = PlayingListBaseGrid;
            SPlayingListBaseView = PlayingListBaseView;
            SMusicPageBaseFrame = MusicPageBaseFrame;
            teachingTipPlayingList = PlayingListBasePopup;
            teachingTipVolume = VolumeBasePopup;
            SPlayContent = PlayContent;
            AsyncDialog = new ContentDialog() { XamlRoot = SContent.XamlRoot, CloseButtonCommand = null };
            equalizerPage = new Pages.DialogPages.EqualizerPage();
            SubClassing();

            App.AppWindowLocal = WindowHelper.GetAppWindowForCurrentWindow(this);
            App.AppWindowLocal.Title = App.AppName;
            App.AppWindowLocal.SetIcon("icon.ico");

            InitializeTitleBar(SWindowGridBaseTop.RequestedTheme);

            //RequestedTheme = App.Current.RequestedTheme == ApplicationTheme.Dark ? ElementTheme.Dark : ElementTheme.Light;
            m_wsdqHelper = new WindowsSystemDispatcherQueueHelper();
            m_wsdqHelper.EnsureWindowsSystemDispatcherQueueController();
            SetBackdrop(BackdropType.Mica);
            SetDragRegionForCustomTitleBar(App.AppWindowLocal);

            NavView.SelectedItem = NavView.MenuItems[1];
            NavView.IsBackEnabled = false;

            Activated += MainWindow_Activated;
            WindowGridBase.ActualThemeChanged += WindowGridBase_ActualThemeChanged;
            App.audioPlayer.SourceChanged += AudioPlayer_SourceChanged;
            App.audioPlayer.PlayEnd += AudioPlayer_PlayEnd;
            App.audioPlayer.PlayStateChanged += AudioPlayer_PlayStateChanged;
            App.audioPlayer.TimingChanged += AudioPlayer_TimingChanged;
            App.audioPlayer.CacheLoadedChanged += AudioPlayer_CacheLoadedChanged;
            App.audioPlayer.CacheLoadingChanged += AudioPlayer_CacheLoadingChanged;
            App.audioPlayer.VolumeChanged += AudioPlayer_VolumeChanged;
            App.playingList.NowPlayingImageLoading += PlayingList_NowPlayingImageLoading;
            App.playingList.NowPlayingImageLoaded += PlayingList_NowPlayingImageLoaded;
            App.lyricManager.PlayingLyricSelectedChange += (_) =>
            {
                if (SWindowGridBase.Visibility == Visibility.Visible && !isMinSize)
                {
                    if (_ != null)
                    {
                        AppTitleTextBlock.Text = $"{App.AppName} -";
                        LyricTextBlock.Text = $" {_.Lyric}";
                    }
                    else
                    {
                        AppTitleTextBlock.Text = $"{App.AppName}";
                        LyricTextBlock.Text = null;
                    }
                }
                //System.Diagnostics.Debug.WriteLine("233");
            };

            loadingst.Children.Add(loadingprogress);
            loadingst.Children.Add(loadingtextBlock);

            // 第一次点击不会响应动画。。。
            App.LoadSettings();
            ReadLAE();

            RegisterHotKeys();
        }

        public async void ReadLAE()
        {
            if (App.LAE == null) return;

            string b = "";
            foreach (var arg in App.LAE.Arguments)
            {
                b += arg + "\n";
            }
            await ShowDialog("LAE", b);
            AppTitleTextBlock.Text = b;
        }

        #region init TitleBar
        public void InitializeTitleBar(ElementTheme theme)
        {
            if (AppWindowTitleBar.IsCustomizationSupported())
            {
                InitializeTitleBara(App.AppWindowLocal.TitleBar, theme);
            }
            else
            {
                ExtendsContentIntoTitleBar = true;
                SetTitleBar(AppTitleBar);
                AppTitleBar.Height = 28;
                AppTitleBar.Margin = new Thickness(0);
                NavView.Margin = new Thickness(0, 28, 0, 0);
                AppTitleTextBlock.Margin = new Thickness(18, 0, 0, 0);
                if (theme == ElementTheme.Dark)
                {
                    WindowGridBase.Background = new SolidColorBrush(Color.FromArgb(255, 32, 32, 32));
                    AppTitleBar.Background = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
                }
                else
                {
                    //w10TitleBarColorReplaceBaseGrid.Visibility = Visibility.Visible;
                    WindowGridBase.Background = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
                    AppTitleBar.Background = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
                }
            }
        }

        public static void InitializeTitleBara(AppWindowTitleBar bar, ElementTheme theme)
        {
            bar.ExtendsContentIntoTitleBar = true;

            bool defaultLightTheme = false; ;
            bool defaultDarkTheme = false; ;
            if (theme == ElementTheme.Default)
            {
                defaultLightTheme = App.Current.RequestedTheme == ApplicationTheme.Light;
                defaultDarkTheme = App.Current.RequestedTheme == ApplicationTheme.Dark;
            }

            if (theme == ElementTheme.Light || defaultLightTheme)
            {
                bar.ButtonBackgroundColor = Colors.Transparent;
                bar.ButtonForegroundColor = Colors.Black;
                bar.ButtonHoverBackgroundColor = Color.FromArgb(20, 0, 0, 0);
                bar.ButtonHoverForegroundColor = Colors.Black;
                bar.ButtonPressedBackgroundColor = Color.FromArgb(10, 0, 0, 0);
                bar.ButtonPressedForegroundColor = Color.FromArgb(100, 0, 0, 0);
                bar.ButtonInactiveBackgroundColor = Colors.Transparent;
                bar.ButtonInactiveForegroundColor = Color.FromArgb(50, 0, 0, 0);
            }
            else if (theme == ElementTheme.Dark || defaultDarkTheme)
            {
                bar.ButtonBackgroundColor = Colors.Transparent;
                bar.ButtonForegroundColor = Colors.White;
                bar.ButtonHoverBackgroundColor = Color.FromArgb(20, 255, 255, 255);
                bar.ButtonHoverForegroundColor = Colors.White;
                bar.ButtonPressedBackgroundColor = Color.FromArgb(10, 255, 255, 255);
                bar.ButtonPressedForegroundColor = Color.FromArgb(100, 255, 255, 255);
                bar.ButtonInactiveBackgroundColor = Colors.Transparent;
                bar.ButtonInactiveForegroundColor = Color.FromArgb(50, 255, 255, 255);
            }
        }
        #endregion

        #region Dialog
        static ScrollViewer dialogScrollViewer = new();
        static bool dialogShow = false;
        static List<object[]> dialogShowObjects = new();
        public static async Task<ContentDialogResult> ShowDialog(
            object title, object content,
            string closeButtonText = "确定", string primaryButtonText = null)
        {
            ContentDialogResult result = default;
            if (!dialogShow)
            {
                dialogShow = true;
                AsyncDialog.Title = title;
                if (content is string)
                {
                    dialogScrollViewer.Content = new TextBlock() { Text = content as string, TextWrapping = TextWrapping.Wrap };
                    AsyncDialog.Content = dialogScrollViewer;
                }
                else
                    AsyncDialog.Content = content;
                AsyncDialog.Background = App.Current.Resources["AcrylicNormal"] as AcrylicBrush;
                AsyncDialog.CloseButtonText = closeButtonText;
                AsyncDialog.PrimaryButtonText = primaryButtonText;
                AsyncDialog.CloseButtonCommand = null;
                AsyncDialog.XamlRoot = SContent.XamlRoot;
                AsyncDialog.RequestedTheme = SWindowGridBaseTop.RequestedTheme;
                result = await AsyncDialog.ShowAsync();
                dialogShow = false;

                if (dialogShowObjects.Any())
                {
                    var a = dialogShowObjects[0];
                    dialogShowObjects.Remove(a);
                    await ShowDialog(a[0], a[1], (string)a[2], (string)a[3]);
                }
            }
            else
            {
                dialogShowObjects.Add(new object[] { title, content, closeButtonText, primaryButtonText });
            }
            return result;
        }

        static Pages.DialogPages.EqualizerPage equalizerPage;
        public static async Task ShowEqualizerDialog()
        {
            await ShowDialog("音频设置", equalizerPage);
        }

        static StackPanel loadingst = new();
        static ProgressRing loadingprogress = new() { IsIndeterminate = true, Width = 50, Height = 50 };
        static TextBlock loadingtextBlock = new() { Text = "", HorizontalAlignment = HorizontalAlignment.Center, TextWrapping = TextWrapping.Wrap };
        public static async void ShowLoadingDialog(string title = "正在加载")
        {
            SetLoadingText("");
            SetLoadingProgressRingValue(100, 0);
            await ShowDialog(title, loadingst, null, null);
        }

        public static void SetLoadingText(string text)
        {
            loadingtextBlock.Text = text;
        }

        public static void SetLoadingProgressRingValue(int maximum, int value)
        {
            if (value == 0) loadingprogress.IsIndeterminate = true;
            else loadingprogress.IsIndeterminate = false;
            loadingprogress.Maximum = maximum;
            loadingprogress.Value = value;
        }

        public static void HideDialog()
        {
            AsyncDialog.Hide();
        }
        #endregion

        #region AudioPlayer Events
        private void AudioPlayer_VolumeChanged(Media.AudioPlayer audioPlayer, object data)
        {
            if (!isPEntered)
            {
                VolumeSlider.Value = (int)((float)data * 100);
            }

            if ((float)data == 0)
            {
                VolumeIconBase.Symbol = Symbol.Mute;
                VolumeAppButton.Icon = new SymbolIcon(Symbol.Mute);
            }
            else
            {
                VolumeIconBase.Symbol = Symbol.Volume;
                VolumeAppButton.Icon = new SymbolIcon(Symbol.Volume);
            }
        }

        private void AudioPlayer_PlayEnd(Media.AudioPlayer audioPlayer)
        {
            if (true)
            {
                AudioPlayer_PlayStateChanged(audioPlayer);
            }
        }

        private void AudioPlayer_CacheLoadedChanged(Media.AudioPlayer audioPlayer)
        {
            PlayRing.Value = 0;
            PlayRing.IsIndeterminate = false;
            PlayingListBaseView.SelectedItem = audioPlayer.MusicData;
        }

        private void AudioPlayer_CacheLoadingChanged(Media.AudioPlayer audioPlayer, object data)
        {
            if (!isMinSize)
            {
                PlayRing.IsIndeterminate = true;
                PlayRing.Foreground = App.Current.Resources["AccentAAFillColorDefaultBrush"] as SolidColorBrush;
            }
        }

        static bool isDeleteImage = true;
        private static void PlayingList_NowPlayingImageLoading(ImageSource imageSource)
        {
            if (!(SPlayContent.Content is Imagezn))
            {
                SPlayContent.Content = new Imagezn() { MinWidth = 0 };
            }
        }

        public static void PlayingList_NowPlayingImageLoaded(ImageSource imageSource)
        {
            if (!isMinSize && !InOpenMusicPage)
            {
                if (imageSource != (SPlayContent.Content as Imagezn)?.Source)
                {
                    (SPlayContent.Content as Imagezn).Source = imageSource;
                }
            }
        }

        private void AudioPlayer_SourceChanged(Media.AudioPlayer audioPlayer)
        {
            bool b = false;
            if (audioPlayer.MusicData != App.playingList.NowPlayingMusicData)
            {
                b = true;
                PlayTitle.Text = audioPlayer.MusicData.Title;
                PlayArtist.Text = audioPlayer.MusicData.ButtonName;
            }

            if (b)
            {
                App.playingList.NowPlayingMusicData = audioPlayer.MusicData;
            }

            PlayingListBaseView.SelectedItem = audioPlayer.MusicData;
        }

        private void AudioPlayer_PlayStateChanged(Media.AudioPlayer audioPlayer)
        {
            if (audioPlayer.NowOutObj?.PlaybackState == PlaybackState.Playing)
            {
                PlayRing.Foreground = App.Current.Resources["AccentAAFillColorDefaultBrush"] as SolidColorBrush;
            }
            else
            {
                PlayRing.Foreground = new SolidColorBrush(Color.FromArgb(255, 225, 225, 0));
            }

            MediaPlayStateViewer.PlaybackState = audioPlayer.NowOutObj != null ? audioPlayer.NowOutObj.PlaybackState : PlaybackState.Paused;
        }

        private void AudioPlayer_TimingChanged(Media.AudioPlayer audioPlayer)
        {
            if (!isMinSize && !InOpenMusicPage)
            {
                if (audioPlayer.FileReader != null)
                {
                    PlayRing.Minimum = 0;
                    PlayRing.Maximum = audioPlayer.FileReader.TotalTime.Ticks;
                    PlayRing.Value = audioPlayer.CurrentTime.Ticks;
                }
            }
        }
        #endregion

        #region Enable Window Backdrop
        public enum BackdropType
        {
            Mica,
            DesktopAcrylic,
            DefaultColor,
        }

        static WindowsSystemDispatcherQueueHelper m_wsdqHelper;
        static BackdropType m_currentBackdrop;
        static MicaController m_micaController;
        static DesktopAcrylicController m_acrylicController;
        static SystemBackdropConfiguration m_configurationSource;

        public static void SetBackdrop(BackdropType type)
        {
            m_currentBackdrop = BackdropType.DefaultColor;
            if (m_micaController != null)
            {
                m_micaController.Dispose();
                m_micaController = null;
            }
            if (m_acrylicController != null)
            {
                m_acrylicController.Dispose();
                m_acrylicController = null;
            }
            SWindow.Activated -= Window_Activated;
            SWindow.Closed -= Window_Closed;
            m_configurationSource = null;

            if (type == BackdropType.Mica)
            {
                if (TrySetMicaBackdrop())
                {
                    m_currentBackdrop = type;
                }
                else
                {
                    type = BackdropType.DesktopAcrylic;
                }
            }
            if (type == BackdropType.DesktopAcrylic)
            {
                if (TrySetAcrylicBackdrop())
                {
                    m_currentBackdrop = type;
                }
                else
                {
                }
            }
        }

        static bool TrySetMicaBackdrop()
        {
            if (MicaController.IsSupported())
            {
                m_configurationSource = new SystemBackdropConfiguration();
                SWindow.Activated += Window_Activated;
                SWindow.Closed += Window_Closed;

                m_configurationSource.IsInputActive = true;
                switch (SWindowGridBaseTop.RequestedTheme)
                {
                    case ElementTheme.Dark: m_configurationSource.Theme = SystemBackdropTheme.Dark; break;
                    case ElementTheme.Light: m_configurationSource.Theme = SystemBackdropTheme.Light; break;
                    case ElementTheme.Default: m_configurationSource.Theme = SystemBackdropTheme.Default; break;
                }

                m_micaController = new MicaController();
                m_micaController.AddSystemBackdropTarget(SWindow.As<ICompositionSupportsSystemBackdrop>());
                m_micaController.SetSystemBackdropConfiguration(m_configurationSource);
                isAcrylicBackdrop = false;
                return true;
            }

            return false;
        }

        static bool isAcrylicBackdrop = false;
        static bool TrySetAcrylicBackdrop()
        {
            if (DesktopAcrylicController.IsSupported())
            {
                m_configurationSource = new SystemBackdropConfiguration();
                SWindow.Activated += Window_Activated;
                SWindow.Closed += Window_Closed;

                m_configurationSource.IsInputActive = true;
                switch (SWindowGridBaseTop.RequestedTheme)
                {
                    case ElementTheme.Dark: m_configurationSource.Theme = SystemBackdropTheme.Dark; break;
                    case ElementTheme.Light: m_configurationSource.Theme = SystemBackdropTheme.Light; break;
                    case ElementTheme.Default: m_configurationSource.Theme = SystemBackdropTheme.Default; break;
                }

                m_acrylicController = new DesktopAcrylicController();

                ElementTheme elementTheme = SWindowGridBaseTop.RequestedTheme;
                if (elementTheme == ElementTheme.Default)
                {
                    elementTheme = App.Current.RequestedTheme == ApplicationTheme.Light ? ElementTheme.Light : ElementTheme.Dark;
                }

                if (elementTheme == ElementTheme.Dark)
                {
                    m_acrylicController.LuminosityOpacity = 1f;
                    m_acrylicController.TintOpacity = 0.5f;
                    m_acrylicController.TintColor = Color.FromArgb(255, 32, 32, 32);
                }
                else if (elementTheme == ElementTheme.Light)
                {
                    m_acrylicController.LuminosityOpacity = 1f;
                    m_acrylicController.TintOpacity = 0.5f;
                    m_acrylicController.TintColor = Color.FromArgb(255, 245, 245, 245);
                }

                m_acrylicController.AddSystemBackdropTarget(SWindow.As<ICompositionSupportsSystemBackdrop>());
                m_acrylicController.SetSystemBackdropConfiguration(m_configurationSource);
                isAcrylicBackdrop = true;
                return true;
            }

            return false;
        }
        #endregion

        #region Window Events
        private void WindowGridBase_Loaded(object sender, RoutedEventArgs e)
        {
            PlayingListBaseView.ItemsSource = App.playingList.NowPlayingList;
        }

        private void WindowGridBase_ActualThemeChanged(FrameworkElement sender, object args)
        {
            if (isAcrylicBackdrop)
            {
                SetBackdrop(BackdropType.DesktopAcrylic);
            }
            InitializeTitleBar(SWindowGridBaseTop.RequestedTheme);
        }

        static ApplicationTheme applicationTheme = App.Current.RequestedTheme;
        public static bool isMinSize = false;
        private void MainWindow_Activated(object sender, WindowActivatedEventArgs args)
        {
            if (args.WindowActivationState == WindowActivationState.PointerActivated ||
                args.WindowActivationState == WindowActivationState.CodeActivated)
            {
                if (!CodeHelper.IsIconic(App.AppWindowLocalHandle))
                {
                    isMinSize = false;
                    //WindowViewStateChanged?.Invoke(true);
                    App.lyricManager.ReCallUpdata();
                    if (!InOpenMusicPage)
                    {
                        PlayingList_NowPlayingImageLoaded(App.playingList.NowPlayingImage);
                    }
                    else
                    {
                        SMusicPage.MusicPageViewStateChange(MusicPageViewState.View);
                    }
                }
            }
            else
            {
                if (CodeHelper.IsIconic(App.AppWindowLocalHandle))
                {
                    isMinSize = true;
                    //WindowViewStateChanged?.Invoke(false);
                    SMusicPage.MusicPageViewStateChange(MusicPageViewState.Hidden);
                }
            }
        }

        private static void Window_Activated(object sender, WindowActivatedEventArgs args)
        {
            //SetBackdrop(BackdropType.DesktopAcrylic);
            if (!isAcrylicBackdrop) UpdataWindowBackdropTheme();
            if (m_currentBackdrop != BackdropType.DefaultColor)
            {
                m_configurationSource.IsInputActive = args.WindowActivationState != WindowActivationState.Deactivated;
            }
        }

        public static void UpdataWindowBackdropTheme()
        {
            switch (SWindowGridBaseTop.RequestedTheme)
            {
                case ElementTheme.Light:
                    m_configurationSource.Theme = SystemBackdropTheme.Light; break;
                case ElementTheme.Dark:
                    m_configurationSource.Theme = SystemBackdropTheme.Dark; break;
                default:
                    m_configurationSource.Theme = SystemBackdropTheme.Default; break;
            }
            m_micaController.SetSystemBackdropConfiguration(m_configurationSource);
        }

        private static void Window_Closed(object sender, WindowEventArgs args)
        {
            /*
            if (m_micaController != null)
            {
                m_micaController.Dispose();
                m_micaController = null;
            }
            if (m_acrylicController != null)
            {
                m_acrylicController.Dispose();
                m_acrylicController = null;
            }*/
            SWindow.Activated -= Window_Activated;
            m_configurationSource = null;
        }

        private void Grid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            SetDragRegionForCustomTitleBar(App.AppWindowLocal);

            try
            {
                PlayingListBaseGrid.Height = TopControlsBaseGrid.ActualHeight - 172;
                PlayingListBaseGrid.Width = 400;
                PlayingListBaseGrid.MaxHeight = 800;
            }
            catch { }
        }

        private void ContentFrame_Loaded(object sender, RoutedEventArgs e)
        {
            SContentFrame = ContentFrame;
        }
        #endregion

        #region Window MinSize Setter
        private delegate IntPtr WinProc(IntPtr hWnd, PInvoke.User32.WindowMessage Msg, IntPtr wParam, IntPtr lParam);
        private WinProc newWndProc = null;
        private IntPtr oldWndProc = IntPtr.Zero;
        [DllImport("user32")]
        private static extern IntPtr SetWindowLong(IntPtr hWnd, PInvoke.User32.WindowLongIndexFlags nIndex, WinProc newProc);
        [DllImport("user32.dll")]
        static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, PInvoke.User32.WindowMessage Msg, IntPtr wParam, IntPtr lParam);

        private void SubClassing()
        {
            //Get the Window's HWND
            var hwnd = this.As<IWindowNative>().WindowHandle;

            newWndProc = new WinProc(NewWindowProc);
            oldWndProc = SetWindowLong(hwnd, PInvoke.User32.WindowLongIndexFlags.GWL_WNDPROC, newWndProc);
        }

        int MinWidth = 460;
        int MinHeight = 460;

        [StructLayout(LayoutKind.Sequential)]
        struct MINMAXINFO
        {
            public PInvoke.POINT ptReserved;
            public PInvoke.POINT ptMaxSize;
            public PInvoke.POINT ptMaxPosition;
            public PInvoke.POINT ptMinTrackSize;
            public PInvoke.POINT ptMaxTrackSize;
        }

        private IntPtr NewWindowProc(IntPtr hWnd, PInvoke.User32.WindowMessage Msg, IntPtr wParam, IntPtr lParam)
        {
            switch (Msg)
            {
                case PInvoke.User32.WindowMessage.WM_GETMINMAXINFO:
                    var dpi = PInvoke.User32.GetDpiForWindow(hWnd);
                    float scalingFactor = (float)dpi / 96;

                    MINMAXINFO minMaxInfo = Marshal.PtrToStructure<MINMAXINFO>(lParam);
                    minMaxInfo.ptMinTrackSize.x = (int)(MinWidth * scalingFactor);
                    minMaxInfo.ptMinTrackSize.y = (int)(MinHeight * scalingFactor);
                    Marshal.StructureToPtr(minMaxInfo, lParam, true);
                    break;

            }
            return CallWindowProc(oldWndProc, hWnd, Msg, wParam, lParam);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("EECDBF0E-BAE9-4CB6-A68E-9598E1CB57BB")]
        internal interface IWindowNative
        {
            IntPtr WindowHandle { get; }
        }
        #endregion

        #region Animate Icon Events
        private void Button_PointerEntered(object sender, PointerRoutedEventArgs e)
        {
            //AnimatedIcon.SetState(this.BackAnimatedIcon, "PointerOver");
        }

        private void Button_PointerExited(object sender, PointerRoutedEventArgs e)
        {
            //AnimatedIcon.SetState(this.BackAnimatedIcon, "Normal");
        }

        private void SetDragRegionForCustomTitleBar(AppWindow appWindow)
        {
            // Check to see if customization is supported.
            // Currently only supported on Windows 11.
            if (AppWindowTitleBar.IsCustomizationSupported()
                && appWindow.TitleBar.ExtendsContentIntoTitleBar)
            {
                double scaleAdjustment = CodeHelper.GetScaleAdjustment(this);
                double rpc = appWindow.TitleBar.RightInset / scaleAdjustment;
                double lpc = appWindow.TitleBar.LeftInset / scaleAdjustment;

                //RightPaddingColumn.Width = new GridLength(appWindow.TitleBar.RightInset / scaleAdjustment);
                //LeftPaddingColumn.Width = new GridLength(appWindow.TitleBar.LeftInset / scaleAdjustment);

                List<RectInt32> dragRectsList = new();

                RectInt32 dragRectL;
                dragRectL.X = (int)(lpc * scaleAdjustment);
                dragRectL.Y = 0;
                dragRectL.Height = (int)(AppTitleBar.ActualHeight * scaleAdjustment);
                dragRectL.Width = (int)((2 + lpc) * scaleAdjustment);
                dragRectsList.Add(dragRectL);

                RectInt32 dragRectR;
                // TOWAIT: when microsoft fix this winui3 bug
                dragRectR.X = (int)((lpc + 2 + (NavView.DisplayMode == NavigationViewDisplayMode.Minimal ? 84 * scaleAdjustment : 42 * scaleAdjustment)));
                dragRectR.Y = 0;
                dragRectR.Height = (int)(AppTitleBar.ActualHeight * scaleAdjustment);
                dragRectR.Width = (int)(rpc * scaleAdjustment * App.AppWindowLocal.Size.Width);
                dragRectsList.Add(dragRectR);

                RectInt32[] dragRects = dragRectsList.ToArray();

                appWindow.TitleBar.SetDragRectangles(dragRects);
            }
        }
        #endregion

        #region NavView Events
        public void UpdataNavViewContentBaseRGClip()
        {
            NavViewContentBase_RGClip.Rect = new Windows.Foundation.Rect(0, 0,
                NavViewContentBase.ActualWidth,
                App.AppWindowLocal.Size.Height - AppTitleBar.ActualHeight);
        }

        public static void SetNavViewContent(Type type, object param = null, NavigationTransitionInfo navigationTransitionInfo = null)
        {
            if (navigationTransitionInfo == null) navigationTransitionInfo = new DrillInNavigationTransitionInfo();
            SContentFrame.Navigate(type, param, navigationTransitionInfo);
            SNavView.IsBackEnabled = SContentFrame.CanGoBack;
            UpdataNavViewSelectedItem(true);
            /*if (type == typeof(ItemListView))
            {
                SNavView.SelectedItem = null;
            }*/
        }

        public static NavigationView SNavView;
        public static Frame SContentFrame;
        public static bool IsBackRequest = false;
        private async void NavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
        {
            if (IsBackRequest || sender.SelectedItem == null || IsJustUpdata)
            {
                return;
            }

            switch ((sender.SelectedItem as NavigationViewItem).Content)
            {
                case "搜索":
                    SetNavViewContent(typeof(SearchPage));
                    break;
                case "推荐":
                    SetNavViewContent(typeof(RecommendPage));
                    break;
                case "浏览":
                    SetNavViewContent(typeof(BrowsePage));
                    break;
                case "下载":
                    SetNavViewContent(typeof(DownloadPage));
                    break;
                case "播放列表":
                    SetNavViewContent(typeof(PlayListPage));
                    break;
                case "历史":
                    SetNavViewContent(typeof(HistoryPage));
                    break;
                case "设置":
                    SetNavViewContent(typeof(SettingPage));
                    break;
                default:
                    await ShowDialog("未添加此功能", $"未添加 \"{(sender.SelectedItem as NavigationViewItem).Content}\" 功能。");
                    break;
            }

            if (ContentFrame.CanGoBack) NavView.IsBackEnabled = true;
            else NavView.IsBackEnabled = false;
        }

        static bool IsJustUpdata = false;
        public static async void UpdataNavViewSelectedItem(bool justUpdata = false)
        {
            if (justUpdata) IsJustUpdata = true;
            switch ((SContentFrame.Content as Page).GetType().ToString().Split('.')[2])
            {
                case "SearchPage":
                    SNavView.SelectedItem = SNavView.MenuItems[1];
                    break;

                case "RecommendPage":
                    SNavView.SelectedItem = SNavView.MenuItems[2];
                    break;

                case "BrowsePage":
                    SNavView.SelectedItem = SNavView.MenuItems[3];
                    break;

                case "DownloadPage":
                    SNavView.SelectedItem = SNavView.MenuItems[5];
                    break;

                case "PlayListPage":
                    SNavView.SelectedItem = SNavView.MenuItems[6];
                    break;

                case "HistoryPage":
                    SNavView.SelectedItem = SNavView.MenuItems[7];
                    break;

                case "SettingPage":
                    SNavView.SelectedItem = SNavView.SettingsItem;
                    break;

                case "ItemListViewSearch":
                case "ItemListViewArtist":
                case "ItemListViewPlayList":
                    SNavView.SelectedItem = null;
                    break;

                case "EmptyPage":
                    TryGoBack();
                    break;

                default:
                    await ShowDialog("未添加此功能", $"未添加 \"{"未知"}\" 功能。");
                    break;
            }
            IsJustUpdata = false;
        }

        public static bool TryGoBack()
        {
            if (InOpenMusicPage)
            {
                OpenOrCloseMusicPage();
                return SContentFrame.CanGoBack;
            }

            if (!SContentFrame.CanGoBack)
                return false;

            IsBackRequest = true;
            SContentFrame.GoBack();
            UpdataNavViewSelectedItem();
            SNavView.IsBackEnabled = SContentFrame.CanGoBack;

            IsBackRequest = false;
            return true;
        }

        private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
        {
            TryGoBack();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            TryGoBack();
        }

        private void NavView_DisplayModeChanged(NavigationView sender, NavigationViewDisplayModeChangedEventArgs args)
        {
            if (sender.DisplayMode == NavigationViewDisplayMode.Minimal)
            {
                AppTitleBar.Margin = new Thickness(90, 0, 0, 0);
            }
            else
            {
                AppTitleBar.Margin = new Thickness(50, 0, 0, 0);
            }
        }

        private void NavViewContentBase_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdataNavViewContentBaseRGClip();
        }

        private void NavView_PaneOpened(NavigationView sender, object args)
        {

        }
        #endregion

        #region Bottom Buttons Events
        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            if (App.audioPlayer.NowOutObj?.PlaybackState == PlaybackState.Playing)
            {
                App.audioPlayer.SetPause();
            }
            else
            {
                App.audioPlayer.SetPlay();
            }
        }

        private async void PlayBeforeButton_Click(object sender, RoutedEventArgs e)
        {
            await App.playingList.PlayPrevious();
        }

        private async void PlayNextButton_Click(object sender, RoutedEventArgs e)
        {
            await App.playingList.PlayNext();
        }

        // VolumeButton
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenOrCloseVolume();
        }

        // PlayingList
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            OpenOrClosePlayingList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OpenOrCloseMusicPage();
        }

        public static void OpenOrCloseVolume()
        {
            teachingTipVolume.IsOpen = !teachingTipVolume.IsOpen;
            teachingTipVolume.IsLightDismissEnabled = true;
        }

        public static void OpenOrClosePlayingList()
        {
            teachingTipPlayingList.IsOpen = !teachingTipPlayingList.IsOpen;
            teachingTipPlayingList.IsLightDismissEnabled = true;
            SPlayingListBaseView.ScrollIntoView(App.playingList.NowPlayingMusicData);
        }

        public static bool InOpenMusicPage { get; set; } = false;
        public static void OpenOrCloseMusicPage()
        {
            if (App.audioPlayer.MusicData == null) return;

            if (!InOpenMusicPage)
            {
                InOpenMusicPage = true;
                SMusicPageBaseFrame.Content = SMusicPage;
                SMusicPageBaseFrame.Visibility = Visibility.Visible;
                AnimateHelper.AnimateOffset(
                    SMusicPageBaseFrame,
                    0, 0, 0, 0.76,
                    0.2f, 1f, 0.22f, 1f,
                    out Visual contentGridVisual, out Compositor compositor, out Vector3KeyFrameAnimation animation);
                contentGridVisual.StartAnimation(nameof(contentGridVisual.Offset), animation);
                /*compositor.GetCommitBatch(CompositionBatchTypes.Animation).Completed += (_, __) =>
                {
                    if (InOpenMusicPage)
                    {
                        SWindowGridBase.Visibility = Visibility.Collapsed;
#if DEBUG
                        System.Diagnostics.Debug.WriteLine("主界面被隐藏。");
#endif
                    }
                };*/

                SMusicPage.MusicPageViewStateChange(MusicPageViewState.View);
            }
            else
            {
                InOpenMusicPage = false;
                /*SWindowGridBase.Visibility = Visibility.Visible;
#if DEBUG
                System.Diagnostics.Debug.WriteLine("主界面被显示。");
#endif*/
                SMusicPageBaseFrame.Content = SMusicPage;
                AnimateHelper.AnimateOffset(
                    SMusicPageBaseFrame,
                    0, (float)SMusicPageBaseGrid.ActualHeight, 0, 0.42,
                    1f, 0f, 1f, 1f,
                    out Visual contentGridVisual, out Compositor compositor, out Vector3KeyFrameAnimation animation);
                contentGridVisual.StartAnimation(nameof(contentGridVisual.Offset), animation);
                compositor.GetCommitBatch(CompositionBatchTypes.Animation).Completed += (_, __) =>
                {
                    if (!InOpenMusicPage)
                    {
                        SMusicPageBaseFrame.Visibility = Visibility.Collapsed;
                    }
                };

                SMusicPage.MusicPageViewStateChange(MusicPageViewState.Hidden);
                PlayingList_NowPlayingImageLoaded(App.playingList.NowPlayingImage);
            }
        }
        #endregion

        #region Key Events
        private void Grid_KeyDown(object sender, KeyRoutedEventArgs e)
        {
        }

        private void Grid_KeyUp(object sender, KeyRoutedEventArgs e)
        {
        }

        private void Grid_PointerPressed(object sender, PointerRoutedEventArgs e)
        {
            if (e.GetCurrentPoint(sender as UIElement).Properties.IsXButton1Pressed)
            {
                TryGoBack();
            }
            else if (e.GetCurrentPoint(sender as UIElement).Properties.IsXButton2Pressed)
            {
                if (ContentFrame.CanGoForward)
                {
                    IsBackRequest = true;
                    ContentFrame.GoForward();
                    UpdataNavViewSelectedItem();
                    SNavView.IsBackEnabled = SContentFrame.CanGoBack;
                    IsBackRequest = false;
                }
            }
        }

        private void Grid_PointerReleased(object sender, PointerRoutedEventArgs e)
        {

        }

        public delegate void DriveInTypeDelegate(Microsoft.UI.Input.PointerDeviceType deviceType);
        public static event DriveInTypeDelegate DriveInTypeEvent;
        public static Microsoft.UI.Input.PointerDeviceType DriveInType = Microsoft.UI.Input.PointerDeviceType.Mouse;
        private void Grid_Tapped(object sender, TappedRoutedEventArgs e)
        {
            bool a = false;

            if (e.PointerDeviceType != DriveInType)
                a = true;

            DriveInType = e.PointerDeviceType;

            if (a)
                DriveInTypeEvent?.Invoke(DriveInType);
        }
        #endregion

        #region Top Controls Events
        bool isPEntered;
        private void VolumeSlider_PointerEntered(object sender, PointerRoutedEventArgs e)
        {
            isPEntered = true;
        }

        private void VolumeSlider_PointerExited(object sender, PointerRoutedEventArgs e)
        {
            isPEntered = false;
        }

        private void VolumeSlider_ValueChanged(object sender, Microsoft.UI.Xaml.Controls.Primitives.RangeBaseValueChangedEventArgs e)
        {
            if (isPEntered)
            {
                App.audioPlayer.Volume = (float)(sender as Slider).Value / (float)100.0;
            }
        }
        #endregion

        #region Volume Grid Button Events
        // 均衡器按钮点击事件
        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            await ShowEqualizerDialog();
        }

        public static float NoVolumeValue = 0;
        // 静音按钮点击事件
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (App.audioPlayer.Volume != 0)
            {
                NoVolumeValue = App.audioPlayer.Volume;
                App.audioPlayer.Volume = 0;
            }
            else
            {
                App.audioPlayer.Volume = NoVolumeValue;
            }
        }
        #endregion

        #region PlayingListView Events
        bool inSelectionChange = false;
        private async void PlayingListBaseView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (inSelectionChange) return;

            inSelectionChange = true;
            if (PlayingListBaseView.SelectedItem != null)
            {
                DataEditor.MusicData data = (DataEditor.MusicData)PlayingListBaseView.SelectedItem;
                if (App.playingList.NowPlayingMusicData != data)
                    await App.playingList.Play(data);
            }
            inSelectionChange = false;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            App.playingList.ClearAll();
        }

        public void UpdataPlayingListShyHeader()
        {
            /*
            // 设置header为顶层
            var headerPresenter = (UIElement)VisualTreeHelper.GetParent((UIElement)PlayingListBaseView.Header);
            var headerContainer = (UIElement)VisualTreeHelper.GetParent(headerPresenter);
            Canvas.SetZIndex(headerContainer, 1);

            var scrollViewer = (VisualTreeHelper.GetChild(PlayingListBaseView, 0) as Border).Child as ScrollViewer;

            CompositionPropertySet scrollerPropertySet = ElementCompositionPreview.GetScrollViewerManipulationPropertySet(scrollViewer);
            Compositor compositor = scrollerPropertySet.Compositor;

            var padingSize = 40;
            // Get the visual that represents our HeaderTextBlock 
            // And define the progress animation string
            var headerVisual = ElementCompositionPreview.GetElementVisual(PlayingListBaseGrid1);
            String progress = $"Clamp(-scroller.Translation.Y / {padingSize}, 0, 1.0)";

            // Shift the header by 50 pixels when scrolling down
            var offsetExpression = compositor.CreateExpressionAnimation($"-scroller.Translation.Y - {progress} * {padingSize}");
            offsetExpression.SetReferenceParameter("scroller", scrollerPropertySet);
            headerVisual.StartAnimation("Offset.Y", offsetExpression);

            
            Visual textVisual = ElementCompositionPreview.GetElementVisual(HeaderBaseTextBlock);
            Vector3 finalOffset = new Vector3(0, 10, 0);
            var headerOffsetAnimation = compositor.CreateExpressionAnimation($"Lerp(Vector3(0,0,0), finalOffset, {progress})");
            headerOffsetAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            headerOffsetAnimation.SetVector3Parameter("finalOffset", finalOffset);
            textVisual.StartAnimation(nameof(Visual.Offset), headerOffsetAnimation);
            

            // Logo scale and transform                                          from               to
            var logoHeaderScaleAnimation = compositor.CreateExpressionAnimation("Lerp(Vector2(1,1), Vector2(0.7, 0.7), " + progress + ")");
            logoHeaderScaleAnimation.SetReferenceParameter("scroller", scrollerPropertySet);

            var logoVisual = ElementCompositionPreview.GetElementVisual(PlayingListBaseTextBlock);
            logoVisual.StartAnimation("Scale.xy", logoHeaderScaleAnimation);

            var logoVisualOffsetYAnimation = compositor.CreateExpressionAnimation($"Lerp(0, 24, {progress})");
            logoVisualOffsetYAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            logoVisual.StartAnimation("Offset.Y", logoVisualOffsetYAnimation);

            var logoVisualOffsetXAnimation = compositor.CreateExpressionAnimation($"Lerp(0, -12, {progress})");
            logoVisualOffsetXAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            logoVisual.StartAnimation("Offset.X", logoVisualOffsetXAnimation);
            
            var stackVisual = ElementCompositionPreview.GetElementVisual(PlayingListBaseStackPanel);
            var stackVisualOffsetXAnimation = compositor.CreateExpressionAnimation($"Lerp(144, 330, {progress})");
            stackVisualOffsetXAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            stackVisual.StartAnimation("Offset.X", stackVisualOffsetXAnimation);

            var stackVisualOffsetYAnimation = compositor.CreateExpressionAnimation($"Lerp(12, 20, {progress})");
            stackVisualOffsetYAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            stackVisual.StartAnimation("Offset.Y", stackVisualOffsetYAnimation);

            var backgroundVisual = ElementCompositionPreview.GetElementVisual(PlayingListBaseRectangle);
            var backgroundVisualOpacityAnimation = compositor.CreateExpressionAnimation($"Lerp(0, 1, {progress})");
            backgroundVisualOpacityAnimation.SetReferenceParameter("scroller", scrollerPropertySet);
            backgroundVisual.StartAnimation("Opacity", backgroundVisualOpacityAnimation);
            */
        }
        #endregion

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
        }

        #region PlayTimePopup
        private void PlayButton_Holding(object sender, HoldingRoutedEventArgs e)
        {
            InitPlayTimePopup();
        }

        private void PlayButton_RightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            InitPlayTimePopup();
        }

        private void InitPlayTimePopup()
        {
            PlayTimeSliderBasePopup.IsOpen = !PlayTimeSliderBasePopup.IsOpen;
            PlayTimeSliderBasePopup.IsLightDismissEnabled = true;
            PlayTimeSliderBasePopup.Closed += PlayTimeSliderBasePopup_Closed;
            App.audioPlayer.TimingChanged += AudioPlayer_TimingChanged1;
            PlayTimeSlider.ValueChanged += PlayTimeSlider_ValueChanged;
        }

        private void PlayTimeSliderBasePopup_Closed(TeachingTip sender, TeachingTipClosedEventArgs args)
        {
            PlayTimeSliderBasePopup.Closed -= PlayTimeSliderBasePopup_Closed;
            App.audioPlayer.TimingChanged -= AudioPlayer_TimingChanged1;
            PlayTimeSlider.ValueChanged -= PlayTimeSlider_ValueChanged;
        }

        private void AudioPlayer_TimingChanged1(Media.AudioPlayer audioPlayer)
        {
            if (audioPlayer.FileReader != null)
            {
                PlayTimeSlider.Minimum = 0;
                PlayTimeSlider.Maximum = audioPlayer.FileReader.TotalTime.Ticks;

                isCodeChangedSilderValue = true;
                PlayTimeSlider.Value = audioPlayer.CurrentTime.Ticks;
                isCodeChangedSilderValue = false;

                PlayTimeTextBlock.Text =
                        $"{audioPlayer.CurrentTime:mm\\:ss}/{audioPlayer.FileReader.TotalTime:mm\\:ss}";
            }
        }

        bool isCodeChangedSilderValue = false;
        private void PlayTimeSlider_ValueChanged(object sender, Microsoft.UI.Xaml.Controls.Primitives.RangeBaseValueChangedEventArgs e)
        {
            if (!isCodeChangedSilderValue && App.audioPlayer.FileReader != null)
            {
                App.audioPlayer.CurrentTime = TimeSpan.FromTicks((long)PlayTimeSlider.Value);
            }
        }
        #endregion

        #region HotKeys
        public void RegisterHotKeys()
        {
            Windows.Win32.Foundation.HWND hwnd = new Windows.Win32.Foundation.HWND(WinRT.Interop.WindowNative.GetWindowHandle(this));

            // 需要注册热键的列表
            var WillRegisterHotKeysList = new List<Tuple<Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS, uint>>()
            {
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0x25),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0x27),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0x28),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0x26),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0xBD),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL, (uint)0xBB),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_NOREPEAT, (uint)0xB0),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_NOREPEAT, (uint)0xB1),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_NOREPEAT, (uint)0xB2),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_NOREPEAT, (uint)0xB3),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL | Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_SHIFT, (uint)0x4F),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL | Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_SHIFT, (uint)0x4C),
                Tuple.Create(Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_CONTROL | Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS.MOD_SHIFT, (uint)0x52)
            };

            var ErrorCantCreatHotKeysList = new List<uint>();

            // 循环列表注册热键
            foreach (Tuple<Windows.Win32.UI.Input.KeyboardAndMouse.HOT_KEY_MODIFIERS, uint> tuple in WillRegisterHotKeysList)
            {
                bool IsRegister = Windows.Win32.PInvoke.RegisterHotKey(
                    hwnd, 0x9999,
                    tuple.Item1,
                    tuple.Item2);
                if (!IsRegister) ErrorCantCreatHotKeysList.Add(tuple.Item2);
            }

            hotKeyPrc = HotKeyPrc;
            var hotKeyPrcPointer = Marshal.GetFunctionPointerForDelegate(hotKeyPrc);
            origPrc = Marshal.GetDelegateForFunctionPointer<Windows.Win32.UI.WindowsAndMessaging.WNDPROC>((IntPtr)Windows.Win32.PInvoke.SetWindowLongPtr(hwnd, Windows.Win32.UI.WindowsAndMessaging.WINDOW_LONG_PTR_INDEX.GWL_WNDPROC, hotKeyPrcPointer));
        }

        private const uint WM_HOTKEY = 0x0312;
        private Windows.Win32.UI.WindowsAndMessaging.WNDPROC origPrc;
        private Windows.Win32.UI.WindowsAndMessaging.WNDPROC hotKeyPrc;

        private Windows.Win32.Foundation.LRESULT HotKeyPrc(Windows.Win32.Foundation.HWND hwnd,
            uint uMsg,
            Windows.Win32.Foundation.WPARAM wParam,
            Windows.Win32.Foundation.LPARAM lParam)
        {
            if (uMsg == WM_HOTKEY)
            {
                string code = lParam.Value.ToString();

                if (code == "2424834" | code == "11599872")
                {
                    App.playingList.PlayPrevious();
                }
                else if (code == "2555906" || code == "11534336")
                {
                    App.playingList.PlayNext();
                }
                else if (code == "11665408" || code == "2490370")
                {
                    App.audioPlayer.CurrentTime = TimeSpan.Zero;
                    App.audioPlayer.SetStop();
                }
                else if (code == "11730944" || code == "2621442")
                {
                    if (App.audioPlayer.NowOutObj?.PlaybackState == PlaybackState.Playing)
                    {
                        App.audioPlayer.SetPause();
                    }
                    else
                    {
                        App.audioPlayer.SetPlay();
                    }
                }
                else if (code == "12255234")
                {
                    App.audioPlayer.Volume += 0.01f;
                }
                else if (code == "12386306")
                {
                    App.audioPlayer.Volume -= 0.01f;
                }
                else if (code == "4980742")
                {
                    // 打开桌面歌词
                }
                else if (code == "5373958")
                {
                    // 随机播放
                }
                else if (code == "5177350")
                {
                    Activate();
                }
                else
                {
                    Debug.WriteLine("Error Hotkey:");
                    Debug.WriteLine(uMsg);
                    Debug.WriteLine(wParam.Value);
                    Debug.WriteLine(lParam.Value);
                }
                return (Windows.Win32.Foundation.LRESULT)IntPtr.Zero;
            }
            return Windows.Win32.PInvoke.CallWindowProc(origPrc, hwnd, uMsg, wParam, lParam);
        }
        #endregion
    }
}

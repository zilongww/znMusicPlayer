﻿namespace NAudio.Flac
{
    public enum ID3v2ImageEncodingRestriction
    {
        NoRestrictions = 0x0,
        PngOrJpegOnly = 0x4
    }
}
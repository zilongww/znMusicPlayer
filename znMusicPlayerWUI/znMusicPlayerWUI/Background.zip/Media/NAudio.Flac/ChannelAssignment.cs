﻿namespace NAudio.Flac
{
    public enum ChannelAssignment
    {
        Independent = 0,
        LeftSide = 1,
        RightSide = 2,
        MidSide = 3,
    }
}
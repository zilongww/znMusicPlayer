namespace NAudio.Flac
{
    public enum FlacNumberType
    {
        SampleNumber,
        FrameNumber
    }
}
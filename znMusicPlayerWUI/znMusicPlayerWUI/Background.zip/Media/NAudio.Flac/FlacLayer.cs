namespace NAudio.Flac
{
    public enum FlacLayer
    {
        Top,
        Metadata,
        Frame,
        SubFrame
    }
}
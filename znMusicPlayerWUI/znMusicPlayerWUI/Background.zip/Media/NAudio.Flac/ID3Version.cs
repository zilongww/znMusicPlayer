﻿namespace NAudio.Flac
{
    public enum ID3Version
    {
        ID3v1 = 1,
        ID3v2_2 = 2,
        ID3v2_3 = 3,
        ID3v2_4 = 4
    }
}
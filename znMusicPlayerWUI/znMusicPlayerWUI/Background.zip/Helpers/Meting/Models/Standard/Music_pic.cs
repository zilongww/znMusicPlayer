﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Meting4Net.Core.Models.Standard
{
    public class Music_pic : Music_model
    {
        public string url { get; set; }
    }
}

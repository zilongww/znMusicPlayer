﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meting4Net.Core.Models.Standard
{
    public class Music_url : Music_model
    {
        public string url { get; set; }
        public int size { get; set; }
        public int br { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meting4Net.Core.Models.Standard
{
    public class Music_lyric : Music_model
    {
        public string lyric { get; set; }
        public string tlyric { get; set; }
    }
}
